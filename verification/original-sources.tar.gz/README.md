# A Lean formalization of the self-similar Lorentz construction

## Verification status

**Complete.** Every local Lean module has compiled successfully, and the
combined project plus the final axiom audit have passed. The actual final
compiler output is recorded in `audit.log`. `PROOF_MANIFEST.json` records the
checked source hashes, pinned versions, theorem name, and logical dependencies.

Verification was performed as staged kernel checks of the modules in
dependency order, followed by the combined `Lorentz.lean` and `Audit.lean`
checks. The provided `verify.py` reproduces a complete sequential source
check from the pinned dependencies.

## What the theorem says

The endpoint is `Lorentz.Construction.lorentz_counterexample` in
`Lorentz/Counterexample.lean`:

```lean
∃ f : ℝ → ℝ,
  ContinuousOn f interval ∧ f 0 = 0 ∧
  (∃ x ∈ interval, f (-x) ≠ -f x) ∧
  ∀ n : ℕ, (∃ p : ℝ[X], IsBest f n p) ∧
    ∀ p : ℝ[X], IsBest f n p → p.eval 0 = 0
```

Here `interval` is `Set.Icc (-1 : ℝ) 1`. The nonoddness witness is inside the
approximation interval. Existence of a best polynomial at every degree is
included, in addition to the assertion about every best polynomial.

The approximation definitions in `Lorentz/Minimax.lean` are:

```lean
def HasErrorBound (f : ℝ → ℝ) (p : ℝ[X]) (E : ℝ) : Prop :=
  ∀ x ∈ Set.Icc (-1 : ℝ) 1, |f x - p.eval x| ≤ E

def IsBest (f : ℝ → ℝ) (n : ℕ) (p : ℝ[X]) : Prop :=
  p.natDegree ≤ n ∧
  ∀ q : ℝ[X], q.natDegree ≤ n → ∀ E : ℝ,
    HasErrorBound f q E → HasErrorBound f p E
```

This is the usual best uniform approximation condition written with upper
bounds: every uniform error bound achieved by a competing polynomial is also
achieved by `p`. For continuous functions on the compact interval it is
equivalent to minimizing the uniform norm. It introduces no assumed best
approximation operator. Alternation proves both bestness and uniqueness in
this project.

## Mathematical construction

Write `T₃(x) = 4x³ - 3x` and `a = √2/2`. The series used in the proof are

\[
G(x)=\sum_{j\ge0}(-1/3)^j T_3^{\circ j}(x),\qquad
H_\beta(x)=\sum_{j\ge0}(-1/3)^j h_\beta(T_3^{\circ j}(x)),
\]

where

\[
h_\beta=T_4-1-2T_5+\beta T_7.
\]

The candidate is

\[
f_\varepsilon(x)=G(T_3(x))+\varepsilon H_\beta(x).
\]

`candidateFunction_eq_orbitSeries` also identifies it, on the approximation
interval, with the single series having polynomial forcing
`qε = T₃ + ε hβ`. It satisfies

\[
f_\varepsilon(x)=q_\varepsilon(x)
  -\tfrac13 f_\varepsilon(T_3(x)).
\]

The parameter `β` is determined by the exact rational coefficient data in
`CertificateData.lean`. Its real algebraic argument `z` is supplied by the
intermediate value theorem as a root of

\[
z^{12}-12z^{10}+54z^8-112z^6+105z^4-36z^2+1=0
\]

in the rational interval `[199238939/100000000, 199238940/100000000]`.
The proof does not need a separate identification of this algebraic root
with a trigonometric expression.

The finite certificate verifies degrees `0` through `6`. Cubic pullback
provides `3m+4` alternating contacts from a degree-`m` certificate. Combining
that fact with the degree-seven functional equation and strong induction on
`n`, using `m = n/3`, supplies certificates for every degree.

Nonoddness is explicit:

\[
f_\varepsilon(a)+f_\varepsilon(-a)=-3\varepsilon\ne0.
\]

## Scope of the perturbation parameter

This formalization proves the existence of a **sufficiently small positive
real `ε`**. The seven thresholds are obtained by local cusp and Lipschitz
estimates, compactness, and a positive finite minimum. All of those steps
are part of the Lean development.

The final theorem does **not** assert that the particular numerical choice
`ε = 10⁻¹⁰` works. That additional quantitative claim from the earlier informal
write-up would require a separate explicit-bound corollary. No such corollary
is used in the counterexample theorem.

## Proof organization

| Modules | Role |
|---|---|
| `Minimax` | Weak alternation, bestness, uniqueness, and the origin condition |
| `Composition`, `AllDegrees` | Cubic alternation lifting and the seven-to-all-degrees induction |
| `Series`, `Trigonometry`, `QuarterSeries` | Uniform convergence, continuity, functional equation, pairing, and phase identities |
| `PolynomialBounds`, `SeriesEstimates`, `AngularSeries`, `LocalComposition` | Polynomial stationarity, the exit-scale estimates, angular-to-spatial transfer, and local pullback |
| `Baseline`, `BaselineLocal` | The actual unperturbed series, its exact extrema, strictness, and local linear cusps |
| `ForcingPolynomials`, `Perturbation` | The actual perturbation series, stationarity, local Lipschitz bounds, and its nonzero even part |
| `Stability`, `CompactStability` | Preservation of finite signed contact bounds for a positive perturbation threshold |
| `CertificateBounds`, `CertificateRoot`, `CertificateData`, `CertificateSigns` | Sound rational interval evaluation, root existence, and exact coefficient/sign data |
| `CertificateGrid`, `CertificateOrder`, `CertificateGeometry`, `CertificateCompleteness` | Contact nodes, ordering, cubic maps, and completeness of the contact sets |
| `CertificateIdentities`, `CertificateFinite`, `CertificatePolynomials`, `CertificateAlternation` | Exact finite minimax identities and usable polynomial/alternation certificates |
| `CertificatePerturbation` | Identification of the actual infinite-series values on the finite invariant grid |
| `ContactGeometry`, `PerturbationContacts`, `BaseCertificates` | The seven perturbed minimax certificates with a common positive parameter |
| `Counterexample` | The final unconditional existence theorem |
| `CertificateNorms` | Additional exact coefficient bounds, also included in the checked project |
| `Audit` | The final theorem statement and its logical-axiom dependency report |

The certificate data use exact rational arithmetic. The finite sign checks
use `decide +kernel`; polynomial identities use proof-producing arithmetic
tactics. External Python calculations are not accepted as proof assumptions.

## Versions and rebuilding

- Lean: `leanprover/lean4:v4.24.0`.
- Mathlib: `v4.24.0`, locked by `lake-manifest.json` to commit
  `f897ebcf72cd16f89ab4577d0c826cd14afaafc7`.

With Lean's `elan` toolchain manager installed, run from this directory:

```sh
lake exe cache get
lake env python3 verify.py
```

The script rechecks every local dependency in order, with one Lean worker
and one local module at a time. It then checks `Audit.lean`, rejects
`sorryAx` and any unexpected axiom in the audit, and writes
`verification.log`. It needs Python 3.9 or newer.

The ordinary project target is also available:

```sh
lake build
lake env lean Audit.lean
```

On a memory-constrained machine, prefer `verify.py` over a parallel build.
The largest exact-identity module can take several minutes to check and
produces a comparatively large `.olean` file. The source archive excludes
`.lake`, generated object files, and downloaded dependencies.

## Assumption audit

`Audit.lean` prints the axioms of the final theorem and several central
intermediate results. The recorded output for the final theorem is:

```text
'Lorentz.Construction.lorentz_counterexample' depends on axioms:
[propext, Classical.choice, Quot.sound]
```

These are Lean's standard logical axioms. No new mathematical axiom,
`sorry`, `admit`, or `native_decide` is used by the source development.
