import Lorentz.Counterexample
import Lorentz.CertificateNorms

/-! Formalization of the self-similar Lorentz construction. -/
