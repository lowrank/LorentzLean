import Lorentz

/-! The dependency list below should contain only Lean's standard logical
axioms: `propext`, `Classical.choice`, and `Quot.sound`. -/

#check Lorentz.Construction.lorentz_counterexample
#print axioms Lorentz.Construction.lorentz_counterexample
#print axioms Lorentz.all_degrees_of_selfsimilar
#print axioms Lorentz.Alternates.isBest
#print axioms Lorentz.Certificate.gridPerturbation_eq_actualH
